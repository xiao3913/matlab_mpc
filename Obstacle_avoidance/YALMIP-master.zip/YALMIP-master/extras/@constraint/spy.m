function S = spy(X)
S = spy(lmi(X));