function [constraints] = cons(constraints,params,k,z_mpc,z,u_mpc,i)

A = [1                                                   params.v0*params.Ts           0;
     -tan(0)/(params.rou*params.l)*params.v0*params.Ts             1                   0;
     params.v0*params.Ts/params.rou                                0                   1];

B = [0   params.v0*params.Ts/(params.l*cos(0)^2)   0]';

C = [0   (tan(0)/params.l-1/params.rou-0/(params.l*cos(0)^2))*params.v0*params.Ts   params.v0*params.Ts]';


if k == 1
    
    constraints = [constraints, z_mpc(k,1:end)' ==  A * z(i,4:6)' + B * u_mpc(k) + C];
    
else
    constraints = [constraints, z_mpc(k,1:end)' == A * z_mpc(k-1,1:end)' + B * u_mpc(k) + C];
    
end